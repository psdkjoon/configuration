return {
  -- {
  --   "neovim/nvim-lspconfig",
  --   config = function()
  --     require "configs.lspconfig"
  --   end,
  -- },
  {
    "williamboman/mason.nvim",
    opts = {
      ensure_installed = {
        "bash-language-server",
        "black",
        "clang-format",
        "clangd",
        "css-lsp",
        "gofumpt",
        "gopls",
        "html-lsp",
        "lua-language-server",
        "pyright",
        "rust-analyzer",
        "shfmt",
        "stylua",
      },
    },
  },
  {
    "nvimtools/none-ls.nvim",
    event = "VeryLazy",
    main = "null-ls",
    dependencies = { "nvim-lua/plenary.nvim" },
    opts = function()
      return require "configs.null-ls"
    end,
  },
  {
    "nvimtools/none-ls-extras.nvim",
    event = "VeryLazy",
  },
  {
    "nvim-treesitter/nvim-treesitter",
    opts = {
      fold = { enable = true },
      ensure_installed = {
        "vim",
        "lua",
        "cpp",
        "bash",
        "python",
        "rust",
        "go",
      },
    },
  },
  {
    "S1M0N38/love2d.nvim",
    event = "VeryLazy",
    version = "2.*",
    opts = {},
    keys = {
      { "<leader>l", ft = "lua", desc = "LÖVE" },
      { "<leader>ll", "<cmd>write<cr><cmd>LoveRun<cr>", ft = "lua", desc = "Run LÖVE" },
      { "<leader>ls", "<cmd>LoveStop<cr>", ft = "lua", desc = "Stop LÖVE" },
    },
  },
}
