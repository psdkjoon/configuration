require("nvchad.configs.lspconfig").defaults()

local servers = { "html", "cssls", "clangd", "pyright", "bashls", "gopls", "qmlls", "lua_ls" }
vim.lsp.enable(servers)

vim.lsp.config["luals"] = {
  settings = {
    Lua = {
      diagnostics = {
        disable = {
          "lowercase-global",
          "duplicate-set-field",
          "duplicate-doc-field",
        },
      },
      workspace = {
        userThirdParty = { os.getenv "HOME" .. "/.local/share/LuaAddons" },
      },
    },
  },
}
