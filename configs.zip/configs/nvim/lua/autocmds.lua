require "nvchad.autocmds"

vim.api.nvim_create_autocmd({ "BufWinLeave", "BufWritePre" }, {
  pattern = "*",
  callback = function()
    if vim.fn.expand "<afile>" ~= "" then
      vim.cmd "mkview"
    end
  end,
})

vim.api.nvim_create_autocmd({ "BufWinEnter", "BufWritePost" }, {
  pattern = "*",
  callback = function()
    if vim.fn.expand "<afile>" ~= "" then
      vim.cmd "silent! loadview"
    end
  end,
})

vim.api.nvim_create_autocmd("LspAttach", {
  pattern = "*.lua",
  callback = function(args)
    if args.data.client_id < 3 then
      vim.cmd "silent! LspRestart"
    end
  end,
})
