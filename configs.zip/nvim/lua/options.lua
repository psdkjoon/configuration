require "nvchad.options"

vim.opt.relativenumber = true
vim.cmd "wincmd p"
-- add yours here!

-- local o = vim.o
-- o.cursorlineopt ='both' -- to enable cursorline!
