require "nvchad.mappings"
local map = vim.keymap.set
map({ "n" }, "<Up>", "<Nop>", { silent = true })
map({ "n" }, "<Down>", "<Nop>", { silent = true })
map({ "n" }, "<Left>", "<Nop>", { silent = true })
map({ "n" }, "<Right>", "<Nop>", { silent = true })
map("i", "jk", "<ESC>")
map("n", "<F5>", function()
  vim.cmd "silent! write"
  local ext = vim.fn.expand "%:e"
  if ext == "py" then
    vim.cmd ":term python3 %"
  elseif ext == "c" then
    vim.cmd ":term gcc % -o %< && ./%<"
  elseif ext == "cpp" then
    vim.cmd ":term g++ % -o %< && ./%<"
  elseif ext == "go" then
    vim.cmd ":term go run %"
  elseif ext == "sh" then
    vim.cmd ":term sh %"
  else
    print("No runner defined for ." .. ext)
  end
  vim.cmd "startinsert"
end)
