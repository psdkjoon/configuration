return {
  {
    "stevearc/conform.nvim",
    -- event = 'BufWritePre', -- uncomment for format on save
    opts = require "configs.conform",
  },

  -- These are some examples, uncomment them if you want to see them work!
  {
    "neovim/nvim-lspconfig",
    config = function()
      require "configs.lspconfig"
    end,
  },
  {
    "williamboman/mason.nvim",
    opts = {
      ensure_installed = {
        "bash-language-server",
        "black",
        "clang-format",
        "clangd",
        "css-lsp",
        "gofumpt",
        "gopls",
        "html-lsp",
        "lua-language-server",
        "pyright",
        "rust-analyzer",
        "shfmt",
        "stylua",
      },
    },
  },
  {
    "nvimtools/none-ls.nvim",
    event = "VeryLazy",
    main = "null-ls", -- important: the module name stays "null-ls"
    dependencies = { "nvim-lua/plenary.nvim" },
    opts = function()
      return require "configs.null-ls" -- keep your existing opts table
    end,
  },
  {
    "nvimtools/none-ls-extras.nvim",
    event = "VeryLazy",
  },
  {
    "nvim-treesitter/nvim-treesitter",
    opts = {
      ensure_installed = {
        "vim",
        "lua",
        "cpp",
        "bash",
        "python",
        "rust",
        "go",
      },
    },
  },

  -- {
  -- 	"nvim-treesitter/nvim-treesitter",
  -- 	opts = {
  -- 		ensure_installed = {
  -- 			"vim", "lua", "vimdoc",
  --      "html", "css"
  -- 		},
  -- 	},
  -- },
}
